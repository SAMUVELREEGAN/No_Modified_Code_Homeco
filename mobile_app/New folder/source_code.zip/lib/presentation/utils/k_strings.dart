class KString {
  static const String appTitle = 'HomeCon-Real Estate Directory';
  static const String appName = 'HomeCo-Real Estate';
  static const String appVersion = '1.3';
  static const String appDeveloper = 'QuomodoSoft';
}
